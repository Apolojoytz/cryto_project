from flask import Flask, request, jsonify
import time, random, jwt
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
SECRET_KEY = "super_secret_key_for_jwt"  # change in production

# In-memory stores (demo)
users = {}      # email -> {password_hash, type, verified}
active_otps = {}  # email -> otp

def send_email_otp(email, otp):
    # Simulated email sending — replace with real SMTP in production
    print(f"[SIMULATED EMAIL] OTP for {email}: {otp}")

def generate_otp():
    return str(random.randint(100000, 999999))

def create_jwt(email, account_type):
    payload = {
        "email": email,
        "type": account_type,
        "iat": int(time.time()),
        "exp": int(time.time()) + 3600
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    account_type = data.get('type', 'user')
    if not email or not password:
        return jsonify({"success": False, "message": "email & password required"}), 400
    if email in users:
        return jsonify({"success": False, "message": "email already registered"}), 400
    users[email] = {
        'password_hash': generate_password_hash(password),
        'type': account_type,
        'verified': False
    }
    otp = generate_otp()
    active_otps[email] = otp
    send_email_otp(email, otp)
    return jsonify({"success": True, "message": "OTP sent to email (simulated)"})

@app.route('/verify_otp', methods=['POST'])
def verify_otp():
    data = request.get_json()
    email = data.get('email')
    otp = data.get('otp')
    if active_otps.get(email) != otp:
        return jsonify({"success": False, "message": "invalid OTP"}), 400
    users[email]['verified'] = True
    del active_otps[email]
    return jsonify({"success": True, "message": "email verified"})

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    if email not in users:
        return jsonify({"success": False, "message": "account not found"}), 404
    if not users[email]['verified']:
        return jsonify({"success": False, "message": "email not verified"}), 400
    if not check_password_hash(users[email]['password_hash'], password):
        return jsonify({"success": False, "message": "invalid password"}), 403
    # Send MFA OTP
    otp = generate_otp()
    active_otps[email] = otp
    send_email_otp(email, otp)
    return jsonify({"success": True, "message": "MFA OTP sent to email (simulated)"})

@app.route('/login_mfa', methods=['POST'])
def login_mfa():
    data = request.get_json()
    email = data.get('email')
    otp = data.get('otp')
    if active_otps.get(email) != otp:
        return jsonify({"success": False, "message": "invalid MFA OTP"}), 400
    del active_otps[email]
    token = create_jwt(email, users[email]['type'])
    return jsonify({"success": True, "token": token})

if __name__ == '__main__':
    app.run(port=6000, debug=True)
