E-Voting Demo (Option A) — CLI + Flask Services
==============================================
This package contains a demonstration e-voting system composed of:
- auth_service.py (port 6000): Registration, email OTP (simulated), login + MFA, JWT issuance
- voting_service.py (port 7000): Election management (admin), vote submission, mining, tally (JWT-protected)
- user_cli.py: Command-line client for voters (register, verify, login, vote)
- admin_cli.py: Command-line client for admins (register, verify, login, create election, add candidates, mine, tally)
- blockchain.py: Simple blockchain + Vote structure (used by voting_service.py)

WARNING: Educational demo only. NOT production-ready. See comments in code for security notes.

How to run:
1. Create a virtual env and install requirements:
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
2. Start services in separate terminals:
   python auth_service.py
   python voting_service.py
3. Use the CLI clients in other terminals:
   python user_cli.py
   python admin_cli.py
Ports:
- Auth service: 6000
- Voting service: 7000
