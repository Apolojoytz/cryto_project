# Simple CLI for voters
import requests, time, hashlib

AUTH_URL = 'http://localhost:6000'
VOTE_URL = 'http://localhost:7000'

token = None
email = None

def register():
    global email
    email = input('email: ').strip()
    password = input('password: ').strip()
    r = requests.post(f'{AUTH_URL}/register', json={'email': email, 'password': password, 'type': 'user'})
    print(r.json())
    if r.ok:
        otp = input('Enter OTP shown in auth service console: ').strip()
        v = requests.post(f'{AUTH_URL}/verify_otp', json={'email': email, 'otp': otp})
        print(v.json())

def login():
    global token, email
    email = input('email: ').strip()
    password = input('password: ').strip()
    r = requests.post(f'{AUTH_URL}/login', json={'email': email, 'password': password})
    print(r.json())
    if r.ok:
        otp = input('Enter MFA OTP shown in auth service console: ').strip()
        m = requests.post(f'{AUTH_URL}/login_mfa', json={'email': email, 'otp': otp})
        if m.ok:
            token = m.json().get('token')
            print('Logged in. Token acquired.')
        else:
            print(m.json())

def view_candidates():
    r = requests.get(f'{VOTE_URL}/chain')
    if r.ok:
        # election candidates are not on the chain; we request by trying to fetch tally or a known endpoint
        # For demo, admin adds candidates; user can attempt to vote and will get an error if invalid
        print('Chain info (for debug):')
        print(r.json())
    else:
        print(r.text)

def vote():
    global token
    if not token:
        print('please login first')
        return
    candidate = input('candidate name: ').strip()
    headers = {'Authorization': f'Bearer {token}'}
    r = requests.post(f'{VOTE_URL}/vote', json={'candidate': candidate}, headers=headers)
    print(r.json())

def menu():
    while True:
        print('\n1) Register\n2) Login\n3) Vote\n4) View chain (debug)\n5) Exit')
        c = input('> ').strip()
        if c == '1':
            register()
        elif c == '2':
            login()
        elif c == '3':
            vote()
        elif c == '4':
            view_candidates()
        else:
            break

if __name__ == '__main__':
    menu()
