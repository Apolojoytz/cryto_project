from flask import Flask, request, jsonify
import jwt, hashlib, time
from functools import wraps
from blockchain import Blockchain, Vote

app = Flask(__name__)
SECRET_KEY = "super_secret_key_for_jwt"  # must match auth_service
blockchain = Blockchain(difficulty=3)

# election state
election = { 'status': 'closed', 'candidates': [] }

def auth_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            request.user = payload
        except Exception as e:
            return jsonify({'success': False, 'message': 'invalid/expired token', 'error': str(e)}), 401
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        token = request.headers.get('Authorization', '').replace('Bearer ', '')
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            if payload.get('type') != 'admin':
                return jsonify({'success': False, 'message': 'admin only'}), 403
            request.user = payload
        except Exception as e:
            return jsonify({'success': False, 'message': 'invalid token', 'error': str(e)}), 401
        return f(*args, **kwargs)
    return wrapper

@app.route('/admin/create_election', methods=['POST'])
@admin_required
def create_election():
    election['status'] = 'open'
    election['candidates'] = []
    return jsonify({'success': True, 'message': 'election opened'})

@app.route('/admin/close_election', methods=['POST'])
@admin_required
def close_election():
    election['status'] = 'closed'
    return jsonify({'success': True, 'message': 'election closed'})

@app.route('/admin/add_candidate', methods=['POST'])
@admin_required
def add_candidate():
    name = request.get_json().get('name')
    if not name:
        return jsonify({'success': False, 'message': 'name required'}), 400
    election['candidates'].append(name)
    return jsonify({'success': True, 'candidates': election['candidates']})

@app.route('/vote', methods=['POST'])
@auth_required
def vote():
    if election['status'] != 'open':
        return jsonify({'success': False, 'message': 'election not open'}), 400
    candidate = request.get_json().get('candidate')
    if candidate not in election['candidates']:
        return jsonify({'success': False, 'message': 'invalid candidate'}), 400
    # use hashed email as voter id
    voter_id = hashlib.sha256(request.user['email'].encode()).hexdigest()
    v = Vote(voter_id=voter_id, candidate=candidate)
    ok, msg = blockchain.add_vote(v)
    status = 200 if ok else 400
    return jsonify({'success': ok, 'message': msg}), status

@app.route('/mine', methods=['POST'])
@admin_required
def mine():
    block = blockchain.mine()
    if not block:
        return jsonify({'success': False, 'message': 'no pending votes'}), 400
    return jsonify({'success': True, 'block': block.to_dict()})

@app.route('/tally', methods=['GET'])
@admin_required
def tally():
    return jsonify({'tally': blockchain.tally()})

@app.route('/chain', methods=['GET'])
def chain():
    return jsonify(blockchain.to_dict())

if __name__ == '__main__':
    app.run(port=7000, debug=True)
