# CLI for admins
import requests, time

AUTH_URL = 'http://localhost:6000'
VOTE_URL = 'http://localhost:7000'

token = None
email = None

def register():
    global email
    email = input('admin email: ').strip()
    password = input('password: ').strip()
    r = requests.post(f'{AUTH_URL}/register', json={'email': email, 'password': password, 'type': 'admin'})
    print(r.json())
    if r.ok:
        otp = input('Enter OTP shown in auth service console: ').strip()
        v = requests.post(f'{AUTH_URL}/verify_otp', json={'email': email, 'otp': otp})
        print(v.json())

def login():
    global token, email
    email = input('admin email: ').strip()
    password = input('password: ').strip()
    r = requests.post(f'{AUTH_URL}/login', json={'email': email, 'password': password})
    print(r.json())
    if r.ok:
        otp = input('Enter MFA OTP shown in auth service console: ').strip()
        m = requests.post(f'{AUTH_URL}/login_mfa', json={'email': email, 'otp': otp})
        if m.ok:
            token = m.json().get('token')
            print('Admin logged in. Token acquired.')
        else:
            print(m.json())

def create_election():
    headers = {'Authorization': f'Bearer {token}'}
    r = requests.post(f'{VOTE_URL}/admin/create_election', headers=headers)
    print(r.json())

def add_candidate():
    headers = {'Authorization': f'Bearer {token}'}
    name = input('candidate name: ').strip()
    r = requests.post(f'{VOTE_URL}/admin/add_candidate', json={'name': name}, headers=headers)
    print(r.json())

def close_election():
    headers = {'Authorization': f'Bearer {token}'}
    r = requests.post(f'{VOTE_URL}/admin/close_election', headers=headers)
    print(r.json())

def mine():
    headers = {'Authorization': f'Bearer {token}'}
    r = requests.post(f'{VOTE_URL}/mine', headers=headers)
    print(r.json())

def tally():
    headers = {'Authorization': f'Bearer {token}'}
    r = requests.get(f'{VOTE_URL}/tally', headers=headers)
    print(r.json())

def menu():
    while True:
        print('\n1) Register admin\n2) Login\n3) Create Election (open)\n4) Add Candidate\n5) Close Election\n6) Mine Pending Votes\n7) Tally\n8) Exit')
        c = input('> ').strip()
        if c == '1':
            register()
        elif c == '2':
            login()
        elif c == '3':
            create_election()
        elif c == '4':
            add_candidate()
        elif c == '5':
            close_election()
        elif c == '6':
            mine()
        elif c == '7':
            tally()
        else:
            break

if __name__ == '__main__':
    menu()
