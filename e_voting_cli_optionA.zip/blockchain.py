# Simple blockchain for storing votes (educational demo)
import time, json, hashlib
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class Vote:
    voter_id: str
    candidate: str
    timestamp: float = field(default_factory=time.time)
    def to_dict(self):
        return { 'voter_id': self.voter_id, 'candidate': self.candidate, 'timestamp': self.timestamp }

@dataclass
class Block:
    index: int
    previous_hash: str
    timestamp: float
    votes: List[Dict[str, Any]]
    nonce: int = 0
    hash: str = ''
    def to_dict(self):
        return {
            'index': self.index,
            'previous_hash': self.previous_hash,
            'timestamp': self.timestamp,
            'votes': self.votes,
            'nonce': self.nonce,
            'hash': self.hash
        }

class Blockchain:
    def __init__(self, difficulty=3):
        self.chain = []
        self.pending_votes = []
        self.difficulty = difficulty
        self.voters_set = set()
        self.create_genesis()
    def create_genesis(self):
        genesis = Block(0, '0', time.time(), [], 0, '')
        genesis.hash = self.compute_hash(genesis)
        self.chain.append(genesis)
    def compute_hash(self, block: Block):
        block_content = json.dumps({
            'index': block.index,
            'previous_hash': block.previous_hash,
            'timestamp': block.timestamp,
            'votes': block.votes,
            'nonce': block.nonce
        }, sort_keys=True).encode()
        return hashlib.sha256(block_content).hexdigest()
    def add_vote(self, vote: Vote):
        # check double vote against mined voters
        if vote.voter_id in self.voters_set:
            return False, 'voter already voted'
        # signature step omitted (JWT ensures identity)
        self.pending_votes.append(vote)
        return True, 'vote accepted to pending'
    def mine(self):
        if not self.pending_votes:
            return None
        last = self.chain[-1]
        block = Block(last.index+1, last.hash, time.time(), [v.to_dict() for v in self.pending_votes], 0, '')
        prefix = '0' * self.difficulty
        while True:
            block.hash = self.compute_hash(block)
            if block.hash.startswith(prefix):
                break
            block.nonce += 1
        self.chain.append(block)
        for v in self.pending_votes:
            self.voters_set.add(v.voter_id)
        self.pending_votes = []
        return block
    def tally(self):
        counts = {}
        for block in self.chain:
            for v in block.votes:
                counts[v['candidate']] = counts.get(v['candidate'], 0) + 1
        return counts
    def to_dict(self):
        return {
            'chain': [b.to_dict() for b in self.chain],
            'pending': [v.to_dict() for v in self.pending_votes],
            'difficulty': self.difficulty
        }
